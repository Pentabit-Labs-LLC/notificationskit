package com.pentabit.notificationskit.messaging

import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.pentabit.notificationskit.NotificationsKit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Optional base class for the host's own FCM messaging service -- extend this instead of
 * [FirebaseMessagingService] directly to get token registration and notification building for
 * free. Still requires the usual manifest `<service>` entry pointing at your subclass; Android
 * only allows one such service per app, same as today.
 *
 * What this does for you: forwards new tokens to [NotificationsKit.registerToken], and turns each
 * incoming [RemoteMessage] into a mostly-built [NotificationCompat.Builder] via
 * [NotificationsKitNotificationBuilder] before handing it to [onNotificationBuilt]. What stays
 * entirely yours: deep-link resolution, and calling
 * [NotificationsKit.reportOpened]/`reportDismissed`/`reportConverted` from your own click/dismiss
 * receivers -- this class never calls those, exactly like before this class existed.
 *
 * `NotificationsKit.init(...)` must already have been called (typically in
 * `Application.onCreate()`) before a token arrives or a message is received -- same requirement
 * as calling `registerToken` directly.
 *
 * ```kotlin
 * class MyFcmService : FCMNotificationService() {
 *     override fun notificationChannelId() = "default"
 *     override fun notificationChannelName() = "Notifications"
 *     override fun notificationSmallIcon() = R.drawable.ic_notification
 *     override fun onNotificationBuilt(payload: PushPayload, builder: NotificationCompat.Builder) {
 *         val nid = payload.data["nid"] ?: return
 *         builder.setContentIntent(buildClickPendingIntent(nid))
 *                .setDeleteIntent(buildDismissPendingIntent(nid))
 *         NotificationManagerCompat.from(applicationContext).notify(nid.hashCode(), builder.build())
 *     }
 * }
 * ```
 */
abstract class FCMNotificationService : FirebaseMessagingService(), PushNotificationCallbacks {

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        scope.launch {
            runCatching { NotificationsKit.registerToken(token, currentLanguage()) }
                .onFailure { onTokenRegistrationFailed(token, it) }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val notification = remoteMessage.notification
        // Custom data keys win if you already send your own "click_action"/"link" -- these two
        // only fill in the FCM-composer-set notification.click_action/notification.link fields
        // when you didn't already send an equivalent key yourself.
        val data = remoteMessage.data.toMutableMap()
        notification?.clickAction?.let { data.putIfAbsent("click_action", it) }
        notification?.link?.toString()?.let { data.putIfAbsent("link", it) }
        val payload = PushPayload(
            title = notification?.title ?: remoteMessage.data["title"],
            body = notification?.body ?: remoteMessage.data["body"],
            imageUrl = notification?.imageUrl?.toString() ?: remoteMessage.data["image"],
            data = data,
        )
        scope.launch {
            val builder = NotificationsKitNotificationBuilder.build(
                context = applicationContext,
                payload = payload,
                channelId = notificationChannelId(),
                channelName = notificationChannelName(),
                smallIcon = notificationSmallIcon(),
                channelImportance = notificationChannelImportance(),
            )
            onNotificationBuilt(payload, builder)
        }
    }

    // notificationChannelId/Name/SmallIcon, onNotificationBuilt, notificationChannelImportance
    // and onTokenRegistrationFailed all come from PushNotificationCallbacks -- see that file.
}
