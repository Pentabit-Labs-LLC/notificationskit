package com.pentabit.notificationskit.messaging

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import com.pentabit.notificationskit.internal.NotificationsKitConstants.LOG_TAG
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

/**
 * Turns a [PushPayload] into a mostly-finished [NotificationCompat.Builder] -- channel ensured,
 * title/body set, image downloaded and applied as [NotificationCompat.BigPictureStyle] when
 * present (falls back to [NotificationCompat.BigTextStyle] when there's no image but a body).
 *
 * Deliberately returns the [NotificationCompat.Builder] un-built: attaching
 * `setContentIntent`/`setDeleteIntent` (deep-link resolution, and therefore when
 * `NotificationsKit.reportOpened`/`reportDismissed` end up firing) stays the host app's job, same
 * as always -- this only removes the "assemble the visual notification" boilerplate.
 *
 * Used internally by [FCMNotificationService] and [ADMNotificationService], but public in case a
 * host wants to build a notification outside either base class (e.g. a custom message pipeline).
 */
object NotificationsKitNotificationBuilder {

    suspend fun build(
        context: Context,
        payload: PushPayload,
        channelId: String,
        channelName: String,
        smallIcon: Int,
        channelImportance: Int = NotificationManager.IMPORTANCE_DEFAULT,
    ): NotificationCompat.Builder {
        ensureChannel(context, channelId, channelName, channelImportance)

        val largeImage = payload.imageUrl?.let { downloadBitmap(it) }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(smallIcon)
            .setContentTitle(payload.title)
            .setContentText(payload.body)
            .setAutoCancel(true)

        when {
            largeImage != null -> builder
                .setLargeIcon(largeImage)
                .setStyle(NotificationCompat.BigPictureStyle().bigPicture(largeImage))
            !payload.body.isNullOrBlank() -> builder
                .setStyle(NotificationCompat.BigTextStyle().bigText(payload.body))
        }

        return builder
    }

    private fun ensureChannel(context: Context, channelId: String, channelName: String, importance: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(channelId) != null) return
        manager.createNotificationChannel(NotificationChannel(channelId, channelName, importance))
    }

    private suspend fun downloadBitmap(url: String): Bitmap? = withContext(Dispatchers.IO) {
        runCatching {
            URL(url).openStream().use { BitmapFactory.decodeStream(it) }
        }.onFailure { e ->
            // Falls back to BigTextStyle (see build() above) when this returns null -- logged so
            // a notification that unexpectedly shows as text-only instead of the sender's image
            // is traceable to this instead of looking like the image was never sent at all.
            println("$LOG_TAG big-image download failed ($url): ${e::class.simpleName} — ${e.message}")
        }.getOrNull()
    }
}
