package com.pentabit.notificationskit.data.remote

import com.google.firebase.Firebase
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.remoteConfig
import com.google.firebase.remoteconfig.remoteConfigSettings
import com.pentabit.notificationskit.internal.NotificationsKitConstants.LOG_TAG
import kotlinx.coroutines.tasks.await

/**
 * Uses Firebase.remoteConfig — the same per-app FirebaseRemoteConfig singleton the host app's
 * own Remote Config bootstrap already talks to. Requires the host to have already called
 * FirebaseApp.initializeApp() (normally automatic via the ContentProvider google-services.json
 * wires up) before NotificationsKit.init() runs.
 */
private class AndroidRemoteConfigReader : RemoteConfigReader {
    private val remoteConfig: FirebaseRemoteConfig = Firebase.remoteConfig

    init {
        remoteConfig.setConfigSettingsAsync(remoteConfigSettings { minimumFetchIntervalInSeconds = 3600 })
    }

    override suspend fun fetchAndActivate(): Boolean = try {
        remoteConfig.fetchAndActivate().await()
        true
    } catch (e: Exception) {
        // Firebase RC falls back to the last-activated/default values on failure — non-fatal,
        // matches the parent app's own RemoteConfigBootstrap behavior. Still logged: a fetch
        // failure here (e.g. no network on first cold launch, before any value was ever cached)
        // is exactly why a downstream getString() can come back blank even though the console
        // shows a value configured — this is the log line that explains why.
        println("$LOG_TAG Remote Config fetchAndActivate() failed, falling back to cached/default values: ${e::class.simpleName} — ${e.message}")
        true
    }

    override fun getString(key: String): String = remoteConfig.getString(key)
}

internal actual fun createRemoteConfigReader(): RemoteConfigReader = AndroidRemoteConfigReader()
