package com.pentabit.notificationskit.messaging

import android.content.Intent
import com.amazon.device.messaging.ADMMessageHandlerBase
import com.pentabit.notificationskit.NotificationsKit
import com.pentabit.notificationskit.internal.NotificationsKitConstants.LOG_TAG
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Optional base class for the host's own ADM (Amazon Device Messaging, Fire OS) handler -- extend
 * this instead of [ADMMessageHandlerBase] directly to get token registration and notification
 * building for free, mirroring [FCMNotificationService] on the Google side.
 *
 * Requires the ADM SDK jar vendored locally -- Amazon doesn't publish it to a Maven repository --
 * in BOTH this library's build (see `notificationskit/libs/README.md`) and your app's own build;
 * `compileOnly` dependencies aren't published/transitive, so that part can't be made invisible the
 * way FCM's Maven dependency can.
 *
 * Subclass exactly like Amazon's own documented pattern for [ADMMessageHandlerBase] -- a public
 * no-arg constructor that passes your own class name up (required so Amazon's reflection-based
 * dispatch, which needs a public no-arg constructor on the concrete class, still works; the
 * class-name argument gets threaded up to [ADMMessageHandlerBase] without becoming a constructor
 * parameter your subclass has to expose):
 * ```kotlin
 * class MyAdmService : ADMNotificationService(MyAdmService::class.java.name) {
 *     override fun notificationChannelId() = "default"
 *     override fun notificationChannelName() = "Notifications"
 *     override fun notificationSmallIcon() = R.drawable.ic_notification
 *     override fun onNotificationBuilt(payload: PushPayload, builder: NotificationCompat.Builder) {
 *         val nid = payload.data["nid"] ?: return
 *         builder.setContentIntent(buildClickPendingIntent(nid))
 *                .setDeleteIntent(buildDismissPendingIntent(nid))
 *         NotificationManagerCompat.from(applicationContext).notify(nid.hashCode(), builder.build())
 *     }
 * }
 * ```
 * Also needs the usual ADM manifest entries: the `com.amazon.device.messaging.permission.RECEIVE`
 * permission, a `<uses-library android:name="com.amazon.device.messaging">`, your own
 * `${applicationId}.permission.RECEIVE_ADM_MESSAGE` signature permission, and an
 * `ADMMessageReceiver` subclass wired to this class via its constructor (`ADMMessageReceiver`
 * takes a `Class<out ADMMessageHandlerBase>`, not a manifest meta-data element -- there is no
 * `ADM_MESSAGE_HANDLER` meta-data in Amazon's real API, despite older third-party writeups
 * suggesting one). This class only changes what the handler class itself does, not ADM's own
 * app-level manifest/registration requirements. Verified against Amazon's real documented
 * manifest/API shape and the vendored jar's actual method signatures (not just older docs/
 * examples), but not against a real Fire OS device -- there's no ADM/Fire OS environment
 * available to test this in.
 */
abstract class ADMNotificationService(className: String) : ADMMessageHandlerBase(className), PushNotificationCallbacks {

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onRegistered(registrationId: String) {
        println("$LOG_TAG ADM onRegistered() fired")
        scope.launch {
            runCatching { NotificationsKit.registerToken(registrationId, currentLanguage()) }
                .onFailure { onTokenRegistrationFailed(registrationId, it) }
        }
    }

    override fun onUnregistered(registrationId: String) {
        println("$LOG_TAG ADM onUnregistered() fired -- device de-registered, no action taken (matches previous behavior)")
    }

    override fun onRegistrationError(errorId: String) {
        // Was a silent no-op before -- ADM registration failing is a real failure signal (the
        // Fire OS equivalent of FCM's onNewToken never firing), so it's now at least logged even
        // though there's no token/Throwable pair here to route through onTokenRegistrationFailed.
        println("$LOG_TAG ADM onRegistrationError() fired -- errorId=$errorId (registration failed; no automatic retry -- ADM itself decides when/whether to retry)")
    }

    override fun onMessage(intent: Intent) {
        println("$LOG_TAG ADM onMessage() fired")
        val extras = intent.extras
        val data: Map<String, String> = extras?.keySet().orEmpty().associateWith { key ->
            extras?.getString(key).orEmpty()
        }
        val payload = PushPayload(
            title = data["title"],
            body = data["body"],
            imageUrl = data["image"],
            data = data,
        )
        scope.launch {
            val builder = NotificationsKitNotificationBuilder.build(
                context = applicationContext,
                payload = payload,
                channelId = notificationChannelId(),
                channelName = notificationChannelName(),
                smallIcon = notificationSmallIcon(),
                channelImportance = notificationChannelImportance(),
            )
            onNotificationBuilt(payload, builder)
        }
    }

    // notificationChannelId/Name/SmallIcon, onNotificationBuilt, notificationChannelImportance
    // and onTokenRegistrationFailed all come from PushNotificationCallbacks -- see that file.
}
