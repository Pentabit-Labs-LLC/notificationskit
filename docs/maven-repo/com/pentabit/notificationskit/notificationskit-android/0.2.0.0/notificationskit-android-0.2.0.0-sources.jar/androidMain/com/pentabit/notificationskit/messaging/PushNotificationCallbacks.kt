package com.pentabit.notificationskit.messaging

import android.app.NotificationManager
import androidx.core.app.NotificationCompat

/**
 * Shared contract between [FCMNotificationService] and [ADMNotificationService] -- both bases
 * hand you the same four hooks after building a [PushPayload]/[NotificationCompat.Builder] pair,
 * so the contract (and its docs) lives here once instead of being duplicated -- and risking drift
 * -- across both files. You don't implement this directly: extend [FCMNotificationService] or
 * [ADMNotificationService], which already do.
 *
 * Kotlin interface members are always public, so these are technically part of your subclass's
 * public API -- in practice nothing but the base class itself ever calls them, since the platform
 * (Firebase/ADM) dispatches into your subclass, not the other way around.
 */
interface PushNotificationCallbacks {

    /** Notification channel id to create/use. Same value every call -- Android ignores a channel
     *  name/importance change on an id that already exists, so pick one id per notification
     *  *kind* your app has, not one per message. */
    fun notificationChannelId(): String

    /** User-visible channel name, shown in system notification settings. */
    fun notificationChannelName(): String

    /** Drawable resource id for the small status-bar icon -- required, `NotificationCompat`
     *  refuses to build without one. */
    fun notificationSmallIcon(): Int

    /** Handed the mostly-built notification -- neither base class ever calls
     *  [NotificationManagerCompat.notify] itself. You own everything from here: attach
     *  `setContentIntent`/`setDeleteIntent` (deep-link resolution), pick a notification id, call
     *  `.build()`, and post it (or don't) -- exactly the same amount of control as building the
     *  notification by hand, just handed a finished [NotificationCompat.Builder] instead of a raw
     *  push message. */
    fun onNotificationBuilt(payload: PushPayload, builder: NotificationCompat.Builder)

    /** Importance for a *newly created* channel only -- ignored if [notificationChannelId]
     *  already exists (Android doesn't allow changing an existing channel's importance in code). */
    fun notificationChannelImportance(): Int = NotificationManager.IMPORTANCE_DEFAULT

    /** Called if token registration throws. Default does nothing -- the next token event (or app
     *  launch) will simply retry. Override to log/report it. */
    fun onTokenRegistrationFailed(token: String, error: Throwable) = Unit
}
