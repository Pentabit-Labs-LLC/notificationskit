package com.pentabit.notificationskit.data.remote

import io.ktor.client.HttpClient
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

/**
 * This module's own HTTP client — deliberately independent of any client the host app already
 * has (e.g. the parent app's `secureHttpClient`), so this module has no dependency on host-app
 * internals. The engine is resolved per source set from the Gradle dependency alone (OkHttp on
 * androidMain, Darwin on iosMain) — no engine-specific code needed here. Registered as a Koin
 * `single` (see [com.pentabit.notificationskit.di.notificationsKitModule]) so every repository
 * receives the same instance via constructor injection rather than importing this val directly.
 */
internal val notificationsKitHttpClient: HttpClient by lazy {
    HttpClient {
        install(ContentNegotiation) {
            json(
                Json {
                    ignoreUnknownKeys = true
                    encodeDefaults = true
                },
            )
        }
    }
}
