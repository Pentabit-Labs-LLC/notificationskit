package com.pentabit.notificationskit.data.local

import android.content.Context
import android.provider.Settings
import android.telephony.TelephonyManager
import com.pentabit.notificationskit.PlatformContext

internal actual fun resolveDeviceId(context: PlatformContext): String = runCatching {
    Settings.Secure.getString(context.context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
}.getOrDefault("")

/** SIM/carrier-derived ISO country code — no runtime permission needed for either property. */
internal actual fun resolveCountryIso(context: PlatformContext): String = runCatching {
    val telephonyManager = context.context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
    val simCountry = telephonyManager?.simCountryIso.orEmpty()
    (simCountry.ifBlank { telephonyManager?.networkCountryIso.orEmpty() }).uppercase()
}.getOrDefault("")
