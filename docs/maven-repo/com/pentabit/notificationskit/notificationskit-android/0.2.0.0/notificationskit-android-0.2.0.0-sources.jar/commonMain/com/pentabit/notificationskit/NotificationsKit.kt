package com.pentabit.notificationskit

import com.pentabit.notificationskit.di.notificationsKitModule
import com.pentabit.notificationskit.domain.usecase.InitializeNotificationsKitUseCase
import com.pentabit.notificationskit.domain.usecase.RegisterTokenUseCase
import com.pentabit.notificationskit.domain.usecase.ReportNotificationEventUseCase
import org.koin.core.Koin
import org.koin.dsl.koinApplication
import kotlin.concurrent.Volatile

/**
 * Single facade for the shared notifications/vault pipeline. See the module README for the full
 * contract (including the "Architecture" section this facade's own layering follows); in short,
 * this module owns everything *from a token/event onward* — vault key fetch, CMS registration,
 * CMS event reporting — and nothing about *obtaining* that token or deciding when a tap/dismiss
 * happened, which stay the host app's job:
 *
 *  - Host owns Firebase/ADM SDK setup and hands this module the resulting token → [registerToken].
 *  - Host owns detecting notification taps/dismisses/conversions → [reportOpened]/[reportDismissed]/[reportConverted].
 *  - This module owns: reading its own Remote Config keys, decrypting the vault bearer, fetching
 *    the ApiVault "content" key, and both CMS calls (/device-api, /notification-events).
 *
 * This object itself does no work — it's a thin adapter over a clean-architecture graph
 * (domain use cases + repositories, data repository impls, all wired with Koin — see
 * [com.pentabit.notificationskit.di.notificationsKitModule]). [init] builds that graph as a
 * private, isolated Koin instance scoped to this object; nothing here touches Koin's
 * `GlobalContext`, so a host app's own Koin setup (or lack of one) is unaffected.
 */
object NotificationsKit {
    @Volatile private var koin: Koin? = null
    @Volatile private var config: NotificationsKitConfig = NotificationsKitConfig()

    /**
     * Call once at app startup, AFTER Firebase is already initialized by the host app
     * (`FirebaseApp.initializeApp` on Android / `FirebaseApp.configure()` on iOS — this module
     * does not do that itself). Builds this module's dependency graph and fetches this module's
     * own Remote Config keys (VAULT_BASE_URL, PBL_VAULT_KEY_*, PBL_VAULT_SALT_*, CMS_BASE_URL)
     * and the vault content key.
     *
     * Safe to call again later (e.g. after a Remote Config value changes) — cheap no-ops where
     * nothing changed. [registerToken]/[reportOpened]/[reportDismissed]/[reportConverted] all
     * `check()` that this has been called and awaited at least once.
     */
    suspend fun init(context: PlatformContext, config: NotificationsKitConfig = NotificationsKitConfig()) {
        this.config = config
        val app = koinApplication { modules(notificationsKitModule(context)) }
        koin = app.koin
        app.koin.get<InitializeNotificationsKitUseCase>().invoke()
    }

    /**
     * Registers/refreshes the push token with the CMS. Dedup-checked — only calls the network
     * when [token] differs from the last one successfully synced. Call this from the host's
     * onNewToken callback (FCM or ADM — this module doesn't care which) AND once more at launch
     * with whatever the current token already is.
     *
     * @param language optional override for the in-app-selected language (e.g. the host's own
     *   language preference, matching the parent app's CURRENT_LANGUAGE behavior); when omitted,
     *   falls back to the device's system language.
     */
    suspend fun registerToken(token: String, language: String? = null) {
        requireKoin().get<RegisterTokenUseCase>().invoke(token, config.storePlatform, language)
    }

    /** Call when the user taps a notification carrying an `nid`. */
    suspend fun reportOpened(nid: String) = report(nid, "opened")

    /** Call when a notification is swiped away without being tapped (Android only — iOS has no
     *  "swiped away" delegate callback, see the module README). */
    suspend fun reportDismissed(nid: String) = report(nid, "dismissed")

    /** Call once the tapped notification's deep_link has been successfully acted on. */
    suspend fun reportConverted(nid: String) = report(nid, "converted")

    private suspend fun report(nid: String, eventType: String) {
        requireKoin().get<ReportNotificationEventUseCase>().invoke(nid, eventType)
    }

    private fun requireKoin(): Koin {
        val k = koin
        check(k != null) {
            "NotificationsKit.init(context) must be called (and awaited) before any other NotificationsKit call."
        }
        return k
    }
}
