package com.pentabit.notificationskit.internal

/**
 * The fixed, cross-app contract this module was extracted from (see the parent app's
 * docs/CMS_NOTIFICATIONS_INTEGRATION.md): the same ApiVault *path*, the same six Remote Config
 * key *names*, and the same two CMS endpoints are shared by every app that adopts this module —
 * only the Remote Config *values* (VAULT_BASE_URL, CMS_BASE_URL, and the vault key/salt pair)
 * differ per app. That's exactly why the key names are hardcoded here rather than made
 * configurable, while the values driven by them are always read fresh from Remote Config —
 * nothing vault- or CMS-URL-related is hardcoded to a specific environment/app in this module.
 */
internal object NotificationsKitConstants {
    /** Appended to the Remote-Config-supplied [RC_KEY_VAULT_BASE_URL] to form the full ApiVault
     *  keys endpoint — mirrors how CMS_BASE_URL + "/device-api" works below. */
    const val VAULT_KEYS_PATH = "/api/public/v1/keys"
    const val VAULT_ENV_PROD = "prod"
    const val VAULT_CATEGORY_CONTENT = "content"

    const val RC_KEY_VAULT_BASE_URL = "VAULT_BASE_URL"
    const val RC_KEY_VAULT_KEY_ANDROID = "PBL_VAULT_KEY_AND"
    const val RC_KEY_VAULT_SALT_ANDROID = "PBL_VAULT_SALT_AND"
    const val RC_KEY_VAULT_KEY_IOS = "PBL_VAULT_KEY_IOS"
    const val RC_KEY_VAULT_SALT_IOS = "PBL_VAULT_SALT_IOS"
    const val RC_KEY_CMS_BASE_URL = "CMS_BASE_URL"

    const val PREF_KEY_SYNCED_PUSH_TOKEN = "notificationskit_synced_push_token"

    const val LOG_TAG = "[NotificationsKit]"
}
