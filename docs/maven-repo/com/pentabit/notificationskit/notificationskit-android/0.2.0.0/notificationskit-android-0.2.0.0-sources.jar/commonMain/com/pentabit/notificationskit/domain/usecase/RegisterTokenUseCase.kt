package com.pentabit.notificationskit.domain.usecase

import com.pentabit.notificationskit.StorePlatform
import com.pentabit.notificationskit.domain.repository.DeviceRepository

/** Backs [com.pentabit.notificationskit.NotificationsKit.registerToken]. */
internal class RegisterTokenUseCase(
    private val deviceRepository: DeviceRepository,
) {
    suspend operator fun invoke(token: String, storePlatform: StorePlatform, language: String?) {
        deviceRepository.syncTokenIfNeeded(token, storePlatform, language)
    }
}
