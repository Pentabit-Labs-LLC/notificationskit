package com.pentabit.notificationskit.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class DeviceApiRequest(
    @SerialName("fcm_token") val fcmToken: String,
    @SerialName("old_fcm_token") val oldFcmToken: String,
    @SerialName("device_id") val deviceId: String,
    val platform: String,
    val country: String,
    val language: String,
)
