package com.pentabit.notificationskit.domain.usecase

import com.pentabit.notificationskit.domain.repository.NotificationEventsRepository

/** Backs [com.pentabit.notificationskit.NotificationsKit.reportOpened]/[reportDismissed]/[reportConverted]. */
internal class ReportNotificationEventUseCase(
    private val notificationEventsRepository: NotificationEventsRepository,
) {
    suspend operator fun invoke(nid: String, eventType: String) {
        notificationEventsRepository.report(nid, eventType)
    }
}
