package com.pentabit.notificationskit.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class VaultKeysRequest(
    val env: String,
    val category: String,
)

/**
 * The vault's response shape isn't rigid — it may come back as a `keys: [...]` list (filtered
 * by category) or a flat/`data`/`result`-wrapped `key`. [resolveContentKey] accepts either.
 * Only the "content" category's `key` is ever read here — `provider` (meaningful for the "ai"
 * category in the parent app) is intentionally not modeled at all in this module.
 */
@Serializable
internal data class VaultKeysApiResponse(
    val keys: List<VaultKeyEntry>? = null,
    val key: String? = null,
    @SerialName("api_key") val apiKeySnake: String? = null,
    val apiKey: String? = null,
    val data: VaultKeysApiPayload? = null,
    val result: VaultKeysApiPayload? = null,
)

@Serializable
internal data class VaultKeyEntry(
    val category: String? = null,
    val secrets: VaultKeySecrets? = null,
)

@Serializable
internal data class VaultKeySecrets(
    val key: String? = null,
    @SerialName("api_key") val apiKeySnake: String? = null,
    val apiKey: String? = null,
) {
    fun resolve(): String? =
        key?.takeIf { it.isNotBlank() }
            ?: apiKey?.takeIf { it.isNotBlank() }
            ?: apiKeySnake?.takeIf { it.isNotBlank() }
}

@Serializable
internal data class VaultKeysApiPayload(
    val key: String? = null,
    @SerialName("api_key") val apiKeySnake: String? = null,
    val apiKey: String? = null,
)

internal fun VaultKeysApiResponse.resolveContentKey(category: String): String? {
    keys?.asSequence()
        ?.filter { it.category.isNullOrBlank() || it.category.equals(category, ignoreCase = true) }
        ?.mapNotNull { it.secrets?.resolve() }
        ?.firstOrNull()
        ?.let { return it }

    val payload = data ?: result
    return (key ?: apiKeySnake ?: apiKey ?: payload?.key ?: payload?.apiKeySnake ?: payload?.apiKey)
        ?.trim()
        ?.takeIf { it.isNotBlank() }
}
