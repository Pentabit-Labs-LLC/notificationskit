package com.pentabit.notificationskit.messaging

/**
 * Source-agnostic representation of an incoming push message. [FCMNotificationService] builds one
 * from a `RemoteMessage`, [ADMNotificationService] builds one from an ADM `Intent`'s extras --
 * either way, [NotificationsKitNotificationBuilder] only ever deals with this shape, never an
 * FCM- or ADM-specific type.
 */
data class PushPayload(
    val title: String?,
    val body: String?,
    val imageUrl: String?,
    /**
     * The message's custom data payload, plus (FCM only, when present and not already one of
     * your own keys) `"click_action"` and `"link"` -- FCM's own notification-level click-action
     * and deep-link fields, set from the Firebase console/composer's "notification" block rather
     * than as custom data. ADM has no equivalent concept -- [ADMNotificationService] passes
     * through only the ADM intent's own extras.
     */
    val data: Map<String, String>,
)
