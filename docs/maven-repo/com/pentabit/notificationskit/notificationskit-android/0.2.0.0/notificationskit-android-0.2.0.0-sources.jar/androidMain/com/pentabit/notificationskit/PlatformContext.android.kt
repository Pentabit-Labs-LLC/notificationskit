package com.pentabit.notificationskit

/** Wraps the host's Android [android.content.Context] — pass your Application/Activity context:
 *  `PlatformContext(applicationContext)`. See the commonMain doc comment for why this wraps
 *  rather than `actual typealias`es Context directly. */
actual class PlatformContext(val context: android.content.Context)
