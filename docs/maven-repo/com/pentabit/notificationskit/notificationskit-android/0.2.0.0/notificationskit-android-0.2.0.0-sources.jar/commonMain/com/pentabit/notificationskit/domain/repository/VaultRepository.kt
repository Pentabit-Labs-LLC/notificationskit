package com.pentabit.notificationskit.domain.repository

/**
 * Domain-facing contract for the ApiVault "content" key lifecycle: applying the Remote Config
 * values [com.pentabit.notificationskit.domain.usecase.InitializeNotificationsKitUseCase] just
 * fetched, fetching/caching the "content" category API key, and exposing the CMS base URL that
 * key was resolved against. [com.pentabit.notificationskit.data.repository.VaultRepositoryImpl]
 * is the only implementation — every use case and the other repositories depend on this
 * interface, never the impl, so the vault fetch/decrypt/cache mechanics stay swappable and
 * independently testable.
 */
internal interface VaultRepository {
    /** Applies the Remote Config values the init use case just fetched — nothing is persisted
     *  until this is called. */
    fun applyRemoteConfig(vaultBaseUrl: String, encryptedVaultKey: String, vaultSaltBase64: String, cmsBaseUrl: String)

    /** No-op (returns true immediately) if a content key is already cached, unless [forceRefresh]. */
    suspend fun ensureContentKey(forceRefresh: Boolean = false): Boolean

    /** The currently cached ApiVault "content" API key, or "" if [ensureContentKey] hasn't
     *  succeeded yet. */
    fun currentApiKey(): String

    /** The CMS base URL from the last [applyRemoteConfig] call, or "" before that first call. */
    fun currentCmsBaseUrl(): String
}
