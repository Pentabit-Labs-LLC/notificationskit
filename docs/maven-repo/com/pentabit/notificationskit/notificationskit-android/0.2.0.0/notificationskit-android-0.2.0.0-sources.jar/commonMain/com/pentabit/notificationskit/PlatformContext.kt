package com.pentabit.notificationskit

/**
 * Opaque per-platform handle NotificationsKit needs for the few things Kotlin has no common API
 * for: reading a stable device id, SIM country, and small key/value storage.
 *  - Android: wraps [android.content.Context] — construct with `PlatformContext(applicationContext)`.
 *  - iOS: an empty marker — construct with `PlatformContext()`.
 *
 * Android wraps rather than `actual typealias`es [android.content.Context] on purpose:
 * `Context` is itself an `abstract` class, and Kotlin requires an expect class's modality to
 * exactly match every actual's (a typealias actual inherits the modality of whatever it points
 * to) — so a bare typealias here would force this expect class to also be `abstract`, which
 * would then be incompatible with iOS's plain concrete, directly-instantiable `actual class`
 * below. Wrapping keeps both actuals concrete/final, avoiding that mismatch entirely.
 */
expect class PlatformContext
