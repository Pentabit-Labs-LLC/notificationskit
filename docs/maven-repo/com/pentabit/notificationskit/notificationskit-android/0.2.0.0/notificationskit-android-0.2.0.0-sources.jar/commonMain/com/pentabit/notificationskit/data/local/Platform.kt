package com.pentabit.notificationskit.data.local

/**
 * True on the Android target, false on iOS. Backs both the CMS `platform` field
 * (android/amazon/ios — see [com.pentabit.notificationskit.data.repository.DeviceRepositoryImpl])
 * and which Remote-Config vault key/salt pair (…_AND vs. …_IOS) to read.
 */
internal expect val isAndroidTarget: Boolean

/** Device's system-language code (e.g. "en"), used as the /device-api `language` field unless
 *  the host overrides it with its own in-app-selected language via
 *  [com.pentabit.notificationskit.NotificationsKit.registerToken]. */
internal expect fun resolveSystemLanguage(): String
