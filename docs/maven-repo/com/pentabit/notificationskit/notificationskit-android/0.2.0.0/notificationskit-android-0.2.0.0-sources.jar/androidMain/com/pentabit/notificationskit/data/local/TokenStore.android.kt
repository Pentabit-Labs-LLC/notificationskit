package com.pentabit.notificationskit.data.local

import android.content.Context
import com.pentabit.notificationskit.PlatformContext
import com.pentabit.notificationskit.internal.NotificationsKitConstants.PREF_KEY_SYNCED_PUSH_TOKEN

private const val PREFS_NAME = "notificationskit_prefs"

internal actual fun readStoredToken(context: PlatformContext): String =
    context.context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getString(PREF_KEY_SYNCED_PUSH_TOKEN, "")
        .orEmpty()

internal actual fun writeStoredToken(context: PlatformContext, token: String) {
    context.context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(PREF_KEY_SYNCED_PUSH_TOKEN, token)
        .apply()
}
