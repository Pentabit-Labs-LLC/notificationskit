package com.pentabit.notificationskit.data.local

import java.util.Locale

internal actual val isAndroidTarget: Boolean = true

internal actual fun resolveSystemLanguage(): String = Locale.getDefault().language
