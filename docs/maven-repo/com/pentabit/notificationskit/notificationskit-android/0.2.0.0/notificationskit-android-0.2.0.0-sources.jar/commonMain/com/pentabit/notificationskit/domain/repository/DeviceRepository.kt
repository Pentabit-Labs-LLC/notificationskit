package com.pentabit.notificationskit.domain.repository

import com.pentabit.notificationskit.StorePlatform

/**
 * Domain-facing contract for registering/refreshing a push token with the CMS `/device-api`
 * endpoint. Source-agnostic on purpose — the token may have come from FCM or Amazon's ADM, this
 * module doesn't care, the host app already resolved that before calling
 * [com.pentabit.notificationskit.NotificationsKit.registerToken].
 * [com.pentabit.notificationskit.data.repository.DeviceRepositoryImpl] is the only implementation.
 */
internal interface DeviceRepository {
    /** Dedup-checked: only calls the network when [token] differs from the last one successfully
     *  synced. */
    suspend fun syncTokenIfNeeded(token: String, storePlatform: StorePlatform, languageOverride: String?)
}
