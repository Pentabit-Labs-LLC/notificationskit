package com.pentabit.notificationskit.domain.repository

/**
 * Domain-facing contract over Firebase Remote Config — just enough for this module's own six
 * keys (see [com.pentabit.notificationskit.internal.NotificationsKitConstants]). The actual
 * Firebase SDK calls live behind [com.pentabit.notificationskit.data.remote.RemoteConfigReader]
 * (an `expect`/`actual` per platform);
 * [com.pentabit.notificationskit.data.repository.RemoteConfigRepositoryImpl] is the only
 * implementation of this interface.
 */
internal interface RemoteConfigRepository {
    suspend fun fetchAndActivate(): Boolean
    fun getString(key: String): String
}
