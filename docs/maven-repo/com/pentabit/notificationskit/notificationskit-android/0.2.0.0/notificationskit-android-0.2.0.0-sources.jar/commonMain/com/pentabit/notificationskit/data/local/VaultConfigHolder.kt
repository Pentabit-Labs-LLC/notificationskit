package com.pentabit.notificationskit.data.local

import com.pentabit.notificationskit.data.crypto.decryptVaultBearer

/** In-memory cache of this module's own Remote Config values — populated once per
 *  [com.pentabit.notificationskit.domain.usecase.InitializeNotificationsKitUseCase] run, via
 *  [com.pentabit.notificationskit.data.repository.VaultRepositoryImpl.applyRemoteConfig]. */
internal class VaultConfigHolder {
    /** ApiVault base URL (e.g. "https://apivault.pentabitlabs.com") — Remote-Config-driven, same
     *  as cmsBaseUrl below, NOT hardcoded to a specific environment. */
    var vaultBaseUrl: String = ""
    var encryptedVaultKey: String = ""
    var vaultSaltBase64: String = ""
    var cmsBaseUrl: String = ""

    fun getVaultBearer(): String? {
        if (encryptedVaultKey.isBlank() || vaultSaltBase64.isBlank()) return null
        return decryptVaultBearer(encryptedVaultKey, vaultSaltBase64)
    }
}
