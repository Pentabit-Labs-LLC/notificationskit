package com.pentabit.notificationskit

/**
 * Which platform/store build this is. Drives the CMS `/device-api` `platform` field
 * ("android" / "amazon" / "ios") — see [com.pentabit.notificationskit.data.repository.DeviceRepositoryImpl].
 *
 * The module double-checks this against the actual compile target
 * ([com.pentabit.notificationskit.data.local.isAndroidTarget]) and will log a warning and
 * fall back to the compile-detected platform if the two disagree (e.g. [IOS] passed on an Android
 * build) — so a wrong value here can never make the module report the wrong OS, but it should
 * still be set correctly:
 *  - [GOOGLE] / [AMAZON] can't be auto-detected — "amazon" vs "google" is a build-flavor decision
 *    the *host app* makes (different applicationId, different google-services.json — see the
 *    module README's "Amazon / ADM" section), so the host has to tell us.
 *  - [IOS] is redundant with the compile target (there's only one iOS build), but is still a real
 *    case here rather than left implicit, so every platform the host might build for has an
 *    explicit, self-documenting value to pass — no iOS caller has to guess or reuse [GOOGLE].
 */
enum class StorePlatform { GOOGLE, AMAZON, IOS }

/** Configuration for [NotificationsKit.init]. */
data class NotificationsKitConfig(
    val storePlatform: StorePlatform = StorePlatform.GOOGLE,
)
