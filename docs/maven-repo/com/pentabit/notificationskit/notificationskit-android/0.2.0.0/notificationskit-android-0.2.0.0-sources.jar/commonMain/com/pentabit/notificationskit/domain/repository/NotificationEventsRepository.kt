package com.pentabit.notificationskit.domain.repository

/**
 * Domain-facing contract for reporting a notification interaction to the CMS
 * `/notification-events` endpoint. [eventType] is one of "opened" / "dismissed" / "converted" —
 * see [com.pentabit.notificationskit.NotificationsKit.reportOpened]/[reportDismissed]/[reportConverted].
 * [com.pentabit.notificationskit.data.repository.NotificationEventsRepositoryImpl] is the only
 * implementation.
 */
internal interface NotificationEventsRepository {
    suspend fun report(nid: String, eventType: String)
}
