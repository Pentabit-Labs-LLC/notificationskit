package com.pentabit.notificationskit.data.crypto

/** AES/ECB decrypt of a Remote-Config-delivered encrypted blob, keyed by a base64-encoded hex
 *  AES key (also delivered via Remote Config). See VaultCrypto.android.kt / VaultCrypto.ios.kt —
 *  same algorithm both platforms, different crypto APIs (javax.crypto vs. CoreCrypto). */
internal expect fun decryptVaultString(input: String, base64HexKey: String): String?

/**
 * Decrypts the vault bearer token from its Remote-Config-delivered encrypted-key/salt pair.
 * Returns null (rather than throwing) on any failure — a null here means "check the Remote
 * Config key/salt pair in the ApiVault console," not a code bug.
 */
internal fun decryptVaultBearer(encryptedKey: String, saltBase64: String): String? = try {
    decryptVaultString(encryptedKey.trim(), saltBase64)?.trim()?.takeIf { it.isNotBlank() }
} catch (e: Exception) {
    null
}

internal fun String.isSafeHttpBearer(): Boolean =
    isNotEmpty() && all { it.code in 33..126 }
