package com.pentabit.notificationskit.di

import com.pentabit.notificationskit.PlatformContext
import com.pentabit.notificationskit.data.local.ContentApiKeyHolder
import com.pentabit.notificationskit.data.local.VaultConfigHolder
import com.pentabit.notificationskit.data.remote.notificationsKitHttpClient
import com.pentabit.notificationskit.data.remote.createRemoteConfigReader
import com.pentabit.notificationskit.data.repository.DeviceRepositoryImpl
import com.pentabit.notificationskit.data.repository.NotificationEventsRepositoryImpl
import com.pentabit.notificationskit.data.repository.RemoteConfigRepositoryImpl
import com.pentabit.notificationskit.data.repository.VaultRepositoryImpl
import com.pentabit.notificationskit.domain.repository.DeviceRepository
import com.pentabit.notificationskit.domain.repository.NotificationEventsRepository
import com.pentabit.notificationskit.domain.repository.RemoteConfigRepository
import com.pentabit.notificationskit.domain.repository.VaultRepository
import com.pentabit.notificationskit.domain.usecase.InitializeNotificationsKitUseCase
import com.pentabit.notificationskit.domain.usecase.RegisterTokenUseCase
import com.pentabit.notificationskit.domain.usecase.ReportNotificationEventUseCase
import org.koin.dsl.module

/**
 * This module's entire dependency graph, wired with Koin — see the module README's
 * "Architecture" section for the full domain/data/di layering this backs.
 *
 * Deliberately NOT started as a global Koin instance (`startKoin` / `GlobalContext`): a host app
 * may already run its own Koin (or none at all), so
 * [com.pentabit.notificationskit.NotificationsKit.init] instead builds a private, isolated
 * `KoinApplication` from this module via `koinApplication { modules(notificationsKitModule(...)) }`,
 * which never touches `GlobalContext`. Nothing declared here is reachable from, or visible to,
 * the host app's own DI graph, and the host does not need to know this module uses Koin at all.
 */
internal fun notificationsKitModule(context: PlatformContext) = module {
    single { context }
    single { notificationsKitHttpClient }
    single { createRemoteConfigReader() }
    single { VaultConfigHolder() }
    single { ContentApiKeyHolder() }

    single<RemoteConfigRepository> { RemoteConfigRepositoryImpl(get()) }
    single<VaultRepository> { VaultRepositoryImpl(get(), get(), get()) }
    single<DeviceRepository> { DeviceRepositoryImpl(get(), get(), get()) }
    single<NotificationEventsRepository> { NotificationEventsRepositoryImpl(get(), get(), get()) }

    factory { InitializeNotificationsKitUseCase(get(), get()) }
    factory { RegisterTokenUseCase(get()) }
    factory { ReportNotificationEventUseCase(get()) }
}
