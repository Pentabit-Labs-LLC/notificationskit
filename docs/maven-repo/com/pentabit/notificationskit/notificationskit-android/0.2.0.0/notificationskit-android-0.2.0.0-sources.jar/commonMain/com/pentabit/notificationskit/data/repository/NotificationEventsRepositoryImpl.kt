package com.pentabit.notificationskit.data.repository

import com.pentabit.notificationskit.PlatformContext
import com.pentabit.notificationskit.data.local.readStoredToken
import com.pentabit.notificationskit.data.remote.dto.NotificationEventItem
import com.pentabit.notificationskit.data.remote.dto.NotificationEventsRequest
import com.pentabit.notificationskit.domain.repository.NotificationEventsRepository
import com.pentabit.notificationskit.domain.repository.VaultRepository
import com.pentabit.notificationskit.internal.NotificationsKitConstants.LOG_TAG
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import io.ktor.http.isSuccess

/**
 * [NotificationEventsRepository] implementation. The `fcm_token` sent is always the last
 * **successfully synced** token, not necessarily the device's literal current token — if
 * registerToken() hasn't succeeded yet, the event is skipped rather than sent with an empty
 * token (call registerToken() before any report call). "received" is intentionally never sent
 * (matches the parent app's behavior).
 */
internal class NotificationEventsRepositoryImpl(
    private val context: PlatformContext,
    private val httpClient: HttpClient,
    private val vaultRepository: VaultRepository,
) : NotificationEventsRepository {
    override suspend fun report(nid: String, eventType: String) {
        if (nid.isBlank()) {
            println("$LOG_TAG reportEvent($eventType) skipped — empty nid")
            return
        }

        val syncedToken = readStoredToken(context)
        if (syncedToken.isBlank()) {
            println("$LOG_TAG reportEvent($eventType) skipped — no synced token yet, call registerToken() first")
            return
        }

        if (!vaultRepository.ensureContentKey()) {
            println("$LOG_TAG reportEvent($eventType) skipped — content key unavailable")
            return
        }
        val cmsBaseUrl = vaultRepository.currentCmsBaseUrl()
        if (cmsBaseUrl.isBlank()) {
            println("$LOG_TAG reportEvent($eventType) skipped — CMS_BASE_URL unavailable")
            return
        }

        try {
            val response = httpClient.post("$cmsBaseUrl/notification-events") {
                header(HttpHeaders.Authorization, "Bearer ${vaultRepository.currentApiKey()}")
                contentType(ContentType.Application.Json)
                setBody(
                    NotificationEventsRequest(
                        events = listOf(
                            NotificationEventItem(nid = nid, eventType = eventType, fcmToken = syncedToken),
                        ),
                    ),
                )
            }

            if (response.status.isSuccess()) {
                println("$LOG_TAG reportEvent($eventType) succeeded — HTTP ${response.status.value}")
            } else {
                val errorBody = runCatching { response.bodyAsText() }.getOrDefault("")
                println("$LOG_TAG reportEvent($eventType) failed — HTTP ${response.status.value} ${errorBody.take(300)}")
            }
        } catch (e: Exception) {
            println("$LOG_TAG reportEvent($eventType) exception: ${e::class.simpleName} — ${e.message}")
        }
    }
}
