package com.pentabit.notificationskit.data.repository

import com.pentabit.notificationskit.data.crypto.isSafeHttpBearer
import com.pentabit.notificationskit.data.local.ContentApiKeyHolder
import com.pentabit.notificationskit.data.local.VaultConfigHolder
import com.pentabit.notificationskit.data.remote.dto.VaultKeysApiResponse
import com.pentabit.notificationskit.data.remote.dto.VaultKeysRequest
import com.pentabit.notificationskit.data.remote.dto.resolveContentKey
import com.pentabit.notificationskit.domain.repository.VaultRepository
import com.pentabit.notificationskit.internal.NotificationsKitConstants.LOG_TAG
import com.pentabit.notificationskit.internal.NotificationsKitConstants.VAULT_CATEGORY_CONTENT
import com.pentabit.notificationskit.internal.NotificationsKitConstants.VAULT_ENV_PROD
import com.pentabit.notificationskit.internal.NotificationsKitConstants.VAULT_KEYS_PATH
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * [VaultRepository] implementation — fetches only the "content" category key from the shared
 * ApiVault, the one place this module talks to ApiVault at all. Gated behind the vault bearer
 * decrypted from Remote Config ([VaultConfigHolder]) and posted to
 * `{vaultBaseUrl}/api/public/v1/keys` — the base URL itself is Remote-Config-driven
 * (VAULT_BASE_URL), not hardcoded to one environment, same as cmsBaseUrl. One locked pass so
 * concurrent callers (e.g. a token sync and an event report firing close together) don't
 * double-fetch.
 */
internal class VaultRepositoryImpl(
    private val httpClient: HttpClient,
    private val vaultConfigHolder: VaultConfigHolder,
    private val contentApiKeyHolder: ContentApiKeyHolder,
) : VaultRepository {
    private val fetchMutex = Mutex()

    override fun applyRemoteConfig(vaultBaseUrl: String, encryptedVaultKey: String, vaultSaltBase64: String, cmsBaseUrl: String) {
        vaultConfigHolder.vaultBaseUrl = vaultBaseUrl
        vaultConfigHolder.encryptedVaultKey = encryptedVaultKey
        vaultConfigHolder.vaultSaltBase64 = vaultSaltBase64
        vaultConfigHolder.cmsBaseUrl = cmsBaseUrl
    }

    override suspend fun ensureContentKey(forceRefresh: Boolean): Boolean = fetchMutex.withLock {
        if (!forceRefresh && contentApiKeyHolder.hasKey()) return@withLock true
        if (forceRefresh) contentApiKeyHolder.clear()

        val vaultBaseUrl = vaultConfigHolder.vaultBaseUrl
        if (vaultBaseUrl.isBlank()) {
            println("$LOG_TAG vault base URL unavailable — check the VAULT_BASE_URL Remote Config value")
            return@withLock false
        }

        val bearer = vaultConfigHolder.getVaultBearer()?.trim()
        if (bearer.isNullOrBlank()) {
            println("$LOG_TAG vault bearer unavailable — check the PBL_VAULT_KEY_*/PBL_VAULT_SALT_* Remote Config pair")
            return@withLock false
        }
        if (!bearer.isSafeHttpBearer()) {
            println("$LOG_TAG vault bearer has invalid characters for an HTTP header — check the decrypt")
            return@withLock false
        }

        try {
            val response = httpClient.post("$vaultBaseUrl$VAULT_KEYS_PATH") {
                header(HttpHeaders.Authorization, "Bearer $bearer")
                contentType(ContentType.Application.Json)
                setBody(VaultKeysRequest(env = VAULT_ENV_PROD, category = VAULT_CATEGORY_CONTENT))
            }

            if (!response.status.isSuccess()) {
                val errorBody = runCatching { response.bodyAsText() }.getOrDefault("")
                println("$LOG_TAG content key request failed — HTTP ${response.status.value} ${errorBody.take(300)}")
                return@withLock false
            }

            val key = response.body<VaultKeysApiResponse>().resolveContentKey(VAULT_CATEGORY_CONTENT)
            if (key.isNullOrBlank()) {
                println("$LOG_TAG vault response had no content-category key")
                return@withLock false
            }

            contentApiKeyHolder.setApiKey(key)
            println("$LOG_TAG content key ready")
            true
        } catch (e: Exception) {
            println("$LOG_TAG content key request error: ${e::class.simpleName} — ${e.message}")
            false
        }
    }

    override fun currentApiKey(): String = contentApiKeyHolder.getApiKey()

    override fun currentCmsBaseUrl(): String = vaultConfigHolder.cmsBaseUrl
}
