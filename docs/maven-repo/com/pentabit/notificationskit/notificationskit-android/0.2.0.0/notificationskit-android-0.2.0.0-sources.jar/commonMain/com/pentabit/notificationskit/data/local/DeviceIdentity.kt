package com.pentabit.notificationskit.data.local

import com.pentabit.notificationskit.PlatformContext

/** Stable per-install device identifier — Android: ANDROID_ID; iOS: identifierForVendor. */
internal expect fun resolveDeviceId(context: PlatformContext): String

/**
 * SIM/carrier-derived ISO country code, no runtime permission needed. Android: TelephonyManager's
 * simCountryIso, falling back to networkCountryIso. iOS always returns "" — CoreTelephony's
 * carrier APIs have been unreliable since iOS 16, so this reports nothing rather than a
 * fabricated value (same call this module's parent app already made).
 */
internal expect fun resolveCountryIso(context: PlatformContext): String
