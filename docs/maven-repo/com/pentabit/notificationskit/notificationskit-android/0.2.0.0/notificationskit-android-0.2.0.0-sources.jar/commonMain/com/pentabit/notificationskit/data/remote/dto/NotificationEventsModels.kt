package com.pentabit.notificationskit.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class NotificationEventItem(
    val nid: String,
    @SerialName("event_type") val eventType: String,
    @SerialName("fcm_token") val fcmToken: String,
)

@Serializable
internal data class NotificationEventsRequest(val events: List<NotificationEventItem>)
