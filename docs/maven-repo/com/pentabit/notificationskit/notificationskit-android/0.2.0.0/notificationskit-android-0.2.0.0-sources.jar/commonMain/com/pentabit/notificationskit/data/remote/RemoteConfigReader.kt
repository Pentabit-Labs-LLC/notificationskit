package com.pentabit.notificationskit.data.remote

/** Thin read-only view over Firebase Remote Config — just enough for this module's own five keys. */
internal interface RemoteConfigReader {
    suspend fun fetchAndActivate(): Boolean
    fun getString(key: String): String
}

/**
 * Talks to the SAME FirebaseRemoteConfig singleton the host app's own Remote Config bootstrap
 * uses (Firebase.remoteConfig / FIRRemoteConfig.remoteConfig() are per-process singletons) — this
 * module does not stand up a separate Firebase project. Calling fetchAndActivate() again here is
 * safe/idempotent; it just refreshes the same cached config the host app already fetched.
 */
internal expect fun createRemoteConfigReader(): RemoteConfigReader
