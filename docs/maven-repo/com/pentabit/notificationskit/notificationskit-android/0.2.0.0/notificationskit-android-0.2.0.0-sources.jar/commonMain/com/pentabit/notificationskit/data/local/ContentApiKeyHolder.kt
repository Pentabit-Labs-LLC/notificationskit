package com.pentabit.notificationskit.data.local

import kotlin.concurrent.Volatile

/**
 * Holds the "content" category ApiVault key — the CMS bearer token used for /device-api and
 * /notification-events. In-memory only, refetched each process start; deliberately does NOT
 * also fetch/hold other vault categories (e.g. "ai") — those are each host app's own concern.
 */
internal class ContentApiKeyHolder {
    @Volatile
    private var apiKey: String = ""

    fun hasKey(): Boolean = apiKey.isNotBlank()
    fun getApiKey(): String = apiKey
    fun setApiKey(key: String) { apiKey = key }
    fun clear() { apiKey = "" }
}
