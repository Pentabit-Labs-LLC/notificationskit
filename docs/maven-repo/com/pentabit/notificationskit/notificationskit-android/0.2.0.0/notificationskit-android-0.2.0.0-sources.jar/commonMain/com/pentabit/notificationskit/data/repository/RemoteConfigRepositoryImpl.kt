package com.pentabit.notificationskit.data.repository

import com.pentabit.notificationskit.data.remote.RemoteConfigReader
import com.pentabit.notificationskit.domain.repository.RemoteConfigRepository

/** [RemoteConfigRepository] implementation — delegates straight to the platform
 *  [RemoteConfigReader] (the Android/iOS `actual` behind
 *  [com.pentabit.notificationskit.data.remote.createRemoteConfigReader]). */
internal class RemoteConfigRepositoryImpl(
    private val reader: RemoteConfigReader,
) : RemoteConfigRepository {
    override suspend fun fetchAndActivate(): Boolean = reader.fetchAndActivate()
    override fun getString(key: String): String = reader.getString(key)
}
