package com.pentabit.notificationskit.data.repository

import com.pentabit.notificationskit.PlatformContext
import com.pentabit.notificationskit.StorePlatform
import com.pentabit.notificationskit.data.local.isAndroidTarget
import com.pentabit.notificationskit.data.local.readStoredToken
import com.pentabit.notificationskit.data.local.resolveCountryIso
import com.pentabit.notificationskit.data.local.resolveDeviceId
import com.pentabit.notificationskit.data.local.resolveSystemLanguage
import com.pentabit.notificationskit.data.local.writeStoredToken
import com.pentabit.notificationskit.data.remote.dto.DeviceApiRequest
import com.pentabit.notificationskit.domain.repository.DeviceRepository
import com.pentabit.notificationskit.domain.repository.VaultRepository
import com.pentabit.notificationskit.internal.NotificationsKitConstants.LOG_TAG
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import io.ktor.http.isSuccess

/**
 * [DeviceRepository] implementation. Dedup-checked exactly like the parent app's
 * DeviceApiService:
 *  - first call ever: nothing stored yet, so fcm_token=current, old_fcm_token="".
 *  - token rotated: fcm_token=current, old_fcm_token=<previously synced>.
 *  - unchanged: no-op, no network call.
 * The stored token only advances after a successful (2xx) response, so a failed call is
 * naturally retried with the same old/new pair next time this is called.
 */
internal class DeviceRepositoryImpl(
    private val context: PlatformContext,
    private val httpClient: HttpClient,
    private val vaultRepository: VaultRepository,
) : DeviceRepository {
    override suspend fun syncTokenIfNeeded(token: String, storePlatform: StorePlatform, languageOverride: String?) {
        if (token.isBlank()) {
            println("$LOG_TAG registerToken() called with a blank token — ignoring")
            return
        }

        val storedToken = readStoredToken(context)
        if (storedToken == token) {
            println("$LOG_TAG token unchanged — skipping /device-api call")
            return
        }

        if (!vaultRepository.ensureContentKey()) {
            println("$LOG_TAG skipping /device-api sync — content key unavailable")
            return
        }
        val cmsBaseUrl = vaultRepository.currentCmsBaseUrl()
        if (cmsBaseUrl.isBlank()) {
            println("$LOG_TAG skipping /device-api sync — CMS_BASE_URL unavailable (check Remote Config)")
            return
        }

        val platformLabel = resolvePlatformLabel(storePlatform)

        try {
            val response = httpClient.post("$cmsBaseUrl/device-api") {
                header(HttpHeaders.Authorization, "Bearer ${vaultRepository.currentApiKey()}")
                contentType(ContentType.Application.Json)
                setBody(
                    DeviceApiRequest(
                        fcmToken = token,
                        oldFcmToken = storedToken,
                        deviceId = resolveDeviceId(context),
                        platform = platformLabel,
                        country = resolveCountryIso(context),
                        language = languageOverride?.takeIf { it.isNotBlank() } ?: resolveSystemLanguage(),
                    ),
                )
            }

            if (response.status.isSuccess()) {
                writeStoredToken(context, token)
                println("$LOG_TAG token synced to CMS — platform=$platformLabel")
            } else {
                val errorBody = runCatching { response.bodyAsText() }.getOrDefault("")
                println("$LOG_TAG /device-api sync failed — HTTP ${response.status.value} ${errorBody.take(300)} (will retry next call)")
            }
        } catch (e: Exception) {
            println("$LOG_TAG /device-api sync exception: ${e::class.simpleName} — ${e.message}")
        }
    }

    /**
     * [storePlatform] is host-supplied config and could in theory be wrong (e.g. a shared
     * commonMain call site passing the wrong constant); the compile target ([isAndroidTarget])
     * cannot be — there is exactly one iOS build and exactly one Android build of this module.
     * So the compile target is authoritative and [storePlatform] is checked against it:
     * agreement resolves silently, disagreement is logged (it means the host's
     * [com.pentabit.notificationskit.NotificationsKit.init] call passed the wrong
     * [StorePlatform] for this build) and the compile-detected platform wins either way.
     */
    private fun resolvePlatformLabel(storePlatform: StorePlatform): String {
        if (isAndroidTarget && storePlatform == StorePlatform.IOS) {
            println("$LOG_TAG NotificationsKitConfig.storePlatform=IOS was passed on an Android build — reporting \"android\" instead (fix the host's init() call)")
            return "android"
        }
        if (!isAndroidTarget && storePlatform != StorePlatform.IOS) {
            println("$LOG_TAG NotificationsKitConfig.storePlatform=$storePlatform was passed on an iOS build — reporting \"ios\" instead (fix the host's init() call)")
            return "ios"
        }
        return when (storePlatform) {
            StorePlatform.GOOGLE -> "android"
            StorePlatform.AMAZON -> "amazon"
            StorePlatform.IOS -> "ios"
        }
    }
}
