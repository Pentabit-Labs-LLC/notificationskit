package com.pentabit.notificationskit.domain.usecase

import com.pentabit.notificationskit.data.local.isAndroidTarget
import com.pentabit.notificationskit.domain.repository.RemoteConfigRepository
import com.pentabit.notificationskit.domain.repository.VaultRepository
import com.pentabit.notificationskit.internal.NotificationsKitConstants

/**
 * Runs once per [com.pentabit.notificationskit.NotificationsKit.init] call: fetches this
 * module's fixed Remote Config keys, applies them to [VaultRepository], then fetches the vault
 * "content" key so it's ready before the first [RegisterTokenUseCase]/
 * [ReportNotificationEventUseCase] call.
 */
internal class InitializeNotificationsKitUseCase(
    private val remoteConfigRepository: RemoteConfigRepository,
    private val vaultRepository: VaultRepository,
) {
    suspend operator fun invoke() {
        remoteConfigRepository.fetchAndActivate()

        val vaultBaseUrl = remoteConfigRepository.getString(NotificationsKitConstants.RC_KEY_VAULT_BASE_URL)
        val vaultKeyName = if (isAndroidTarget) NotificationsKitConstants.RC_KEY_VAULT_KEY_ANDROID else NotificationsKitConstants.RC_KEY_VAULT_KEY_IOS
        val vaultSaltName = if (isAndroidTarget) NotificationsKitConstants.RC_KEY_VAULT_SALT_ANDROID else NotificationsKitConstants.RC_KEY_VAULT_SALT_IOS
        val encryptedVaultKey = remoteConfigRepository.getString(vaultKeyName)
        val vaultSaltBase64 = remoteConfigRepository.getString(vaultSaltName)
        val cmsBaseUrl = remoteConfigRepository.getString(NotificationsKitConstants.RC_KEY_CMS_BASE_URL)

        vaultRepository.applyRemoteConfig(vaultBaseUrl, encryptedVaultKey, vaultSaltBase64, cmsBaseUrl)
        vaultRepository.ensureContentKey()
    }
}
