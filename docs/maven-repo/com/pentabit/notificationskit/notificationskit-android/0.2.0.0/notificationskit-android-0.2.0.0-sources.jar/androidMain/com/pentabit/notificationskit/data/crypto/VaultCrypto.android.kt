package com.pentabit.notificationskit.data.crypto

import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/** Moved verbatim from the parent app's VaultCrypto.android.kt. */
internal actual fun decryptVaultString(input: String, base64HexKey: String): String? {
    return try {
        val hexString = Base64.decode(base64HexKey, Base64.DEFAULT).toString(Charsets.UTF_8)
        val key = hexString.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

        val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"))

        val encryptedBytes = Base64.decode(input, Base64.DEFAULT)
        cipher.doFinal(encryptedBytes).toString(Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }
}
