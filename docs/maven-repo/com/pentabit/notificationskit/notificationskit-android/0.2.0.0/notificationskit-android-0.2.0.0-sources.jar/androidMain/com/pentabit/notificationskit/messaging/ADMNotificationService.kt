package com.pentabit.notificationskit.messaging

import android.content.Intent
import com.amazon.device.messaging.ADMMessageHandlerBase
import com.pentabit.notificationskit.NotificationsKit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Optional base class for the host's own ADM (Amazon Device Messaging, Fire OS) handler -- extend
 * this instead of [ADMMessageHandlerBase] directly to get token registration and notification
 * building for free, mirroring [FCMNotificationService] on the Google side.
 *
 * Requires the ADM SDK jar vendored locally -- Amazon doesn't publish it to a Maven repository --
 * in BOTH this library's build (see `notificationskit/libs/README.md`) and your app's own build;
 * `compileOnly` dependencies aren't published/transitive, so that part can't be made invisible the
 * way FCM's Maven dependency can.
 *
 * Subclass exactly like Amazon's own documented pattern for [ADMMessageHandlerBase] -- a public
 * no-arg constructor that passes your own class name up (required so Amazon's reflection-based
 * dispatch, which needs a public no-arg constructor on the concrete class, still works; the
 * class-name argument gets threaded up to [ADMMessageHandlerBase] without becoming a constructor
 * parameter your subclass has to expose):
 * ```kotlin
 * class MyAdmService : ADMNotificationService(MyAdmService::class.java.name) {
 *     override fun notificationChannelId() = "default"
 *     override fun notificationChannelName() = "Notifications"
 *     override fun notificationSmallIcon() = R.drawable.ic_notification
 *     override fun onNotificationBuilt(payload: PushPayload, builder: NotificationCompat.Builder) {
 *         val nid = payload.data["nid"] ?: return
 *         builder.setContentIntent(buildClickPendingIntent(nid))
 *                .setDeleteIntent(buildDismissPendingIntent(nid))
 *         NotificationManagerCompat.from(applicationContext).notify(nid.hashCode(), builder.build())
 *     }
 * }
 * ```
 * Also needs the usual ADM manifest entries (the `amazon.device.messaging.permission.RECEIVE`
 * permission, the `ADM_MESSAGE_HANDLER` meta-data pointing at your subclass, etc.) -- this class
 * only changes what the handler class itself does, not ADM's own app-level manifest/registration
 * requirements. This has not been verified against a real Fire OS build -- there's no ADM/Fire OS
 * environment available to test this in; treat it as a solid-faith implementation of Amazon's
 * documented API shape, not confirmed working.
 */
abstract class ADMNotificationService(className: String) : ADMMessageHandlerBase(className), PushNotificationCallbacks {

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onRegistered(registrationId: String) {
        scope.launch {
            runCatching { NotificationsKit.registerToken(registrationId) }
                .onFailure { onTokenRegistrationFailed(registrationId, it) }
        }
    }

    override fun onUnregistered(registrationId: String) = Unit

    override fun onRegistrationError(errorId: String) = Unit

    override fun onMessage(intent: Intent) {
        val extras = intent.extras
        val data: Map<String, String> = extras?.keySet().orEmpty().associateWith { key ->
            extras?.getString(key).orEmpty()
        }
        val payload = PushPayload(
            title = data["title"],
            body = data["body"],
            imageUrl = data["image"],
            data = data,
        )
        scope.launch {
            val builder = NotificationsKitNotificationBuilder.build(
                context = applicationContext,
                payload = payload,
                channelId = notificationChannelId(),
                channelName = notificationChannelName(),
                smallIcon = notificationSmallIcon(),
                channelImportance = notificationChannelImportance(),
            )
            onNotificationBuilt(payload, builder)
        }
    }

    // notificationChannelId/Name/SmallIcon, onNotificationBuilt, notificationChannelImportance
    // and onTokenRegistrationFailed all come from PushNotificationCallbacks -- see that file.
}
