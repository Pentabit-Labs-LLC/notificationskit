package com.pentabit.notificationskit.data.local

import com.pentabit.notificationskit.PlatformContext

/**
 * The last push token successfully synced to the CMS — this module's own tiny persisted state,
 * independent of any preferences system the host app uses. Android: SharedPreferences.
 * iOS: NSUserDefaults.
 */
internal expect fun readStoredToken(context: PlatformContext): String
internal expect fun writeStoredToken(context: PlatformContext, token: String)
