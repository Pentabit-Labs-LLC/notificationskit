package com.pentabit.notificationskit

/** No Context concept on iOS — construct with `PlatformContext()`. */
actual class PlatformContext
