package com.pentabit.notificationskit.data.local

import com.pentabit.notificationskit.PlatformContext
import com.pentabit.notificationskit.internal.NotificationsKitConstants.PREF_KEY_SYNCED_PUSH_TOKEN
import platform.Foundation.NSUserDefaults

internal actual fun readStoredToken(context: PlatformContext): String =
    NSUserDefaults.standardUserDefaults.stringForKey(PREF_KEY_SYNCED_PUSH_TOKEN).orEmpty()

internal actual fun writeStoredToken(context: PlatformContext, token: String) {
    NSUserDefaults.standardUserDefaults.setObject(token, PREF_KEY_SYNCED_PUSH_TOKEN)
}
