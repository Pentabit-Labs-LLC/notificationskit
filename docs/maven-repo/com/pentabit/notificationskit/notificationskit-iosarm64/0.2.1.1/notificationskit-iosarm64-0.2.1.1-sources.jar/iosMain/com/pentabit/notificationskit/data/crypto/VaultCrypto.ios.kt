package com.pentabit.notificationskit.data.crypto

import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ULongVar
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.refTo
import kotlinx.cinterop.value
import platform.CoreCrypto.CCCrypt
import platform.CoreCrypto.kCCAlgorithmAES
import platform.CoreCrypto.kCCBlockSizeAES128
import platform.CoreCrypto.kCCDecrypt
import platform.CoreCrypto.kCCOptionECBMode
import platform.CoreCrypto.kCCOptionPKCS7Padding
import platform.CoreCrypto.kCCSuccess
import platform.Foundation.NSData
import platform.Foundation.NSString
import platform.Foundation.NSUTF8StringEncoding
import platform.Foundation.create
import platform.posix.memcpy

/**
 * Moved verbatim from the parent app's VaultCrypto.ios.kt. platform.CoreCrypto.* is a Kotlin/Native
 * system-framework binding — no custom cinterop .def file needed (same as the parent app).
 */
@OptIn(BetaInteropApi::class, ExperimentalForeignApi::class)
internal actual fun decryptVaultString(input: String, base64HexKey: String): String? {
    return try {
        val keyBytes = NSData.create(base64EncodedString = base64HexKey, options = 0u) ?: return null
        val hexString = NSString.create(data = keyBytes, encoding = NSUTF8StringEncoding)?.toString()
            ?: return null

        val key = (0 until hexString.length step 2).map { i ->
            hexString.substring(i, i + 2).toInt(16).toByte()
        }.toByteArray()

        val encryptedData = NSData.create(base64EncodedString = input, options = 0u) ?: return null
        val encryptedBytes = ByteArray(encryptedData.length.toInt()).apply {
            encryptedData.bytes?.let { memcpy(this.refTo(0), it, encryptedData.length) }
        }
        val decryptedBytes = ByteArray(encryptedBytes.size + kCCBlockSizeAES128.toInt())

        val decryptedLength = memScoped {
            val dataOutMoved = alloc<ULongVar>()
            val status = CCCrypt(
                op = kCCDecrypt,
                alg = kCCAlgorithmAES,
                options = kCCOptionPKCS7Padding or kCCOptionECBMode,
                key = key.refTo(0),
                keyLength = key.size.toULong(),
                iv = null,
                dataIn = encryptedBytes.refTo(0),
                dataInLength = encryptedBytes.size.toULong(),
                dataOut = decryptedBytes.refTo(0),
                dataOutAvailable = decryptedBytes.size.toULong(),
                dataOutMoved = dataOutMoved.ptr,
            )
            if (status != kCCSuccess.toInt()) {
                println("[NotificationsKit] CCCrypt failed with status: $status")
                return null
            }
            dataOutMoved.value.toInt()
        }

        val decryptedTrimmed = decryptedBytes.copyOf(decryptedLength)
        memScoped {
            NSString.create(
                bytes = decryptedTrimmed.refTo(0).getPointer(this),
                length = decryptedTrimmed.size.toULong(),
                encoding = NSUTF8StringEncoding,
            )?.toString()
        }
    } catch (e: Exception) {
        println("[NotificationsKit] ${e::class.simpleName}: ${e.message}")
        null
    }
}
