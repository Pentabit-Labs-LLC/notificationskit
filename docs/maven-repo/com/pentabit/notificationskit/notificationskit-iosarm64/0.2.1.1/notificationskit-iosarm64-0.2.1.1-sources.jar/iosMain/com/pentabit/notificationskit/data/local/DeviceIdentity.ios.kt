package com.pentabit.notificationskit.data.local

import com.pentabit.notificationskit.PlatformContext
import platform.UIKit.UIDevice

internal actual fun resolveDeviceId(context: PlatformContext): String =
    UIDevice.currentDevice.identifierForVendor?.UUIDString.orEmpty()

/** Always "" on iOS — see the commonMain doc comment on resolveCountryIso. */
internal actual fun resolveCountryIso(context: PlatformContext): String = ""
