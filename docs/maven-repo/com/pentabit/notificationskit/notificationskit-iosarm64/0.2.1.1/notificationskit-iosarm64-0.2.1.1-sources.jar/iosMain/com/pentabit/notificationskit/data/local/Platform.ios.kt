package com.pentabit.notificationskit.data.local

import platform.Foundation.NSLocale
import platform.Foundation.currentLocale
import platform.Foundation.languageCode

internal actual val isAndroidTarget: Boolean = false

internal actual fun resolveSystemLanguage(): String =
    NSLocale.currentLocale.languageCode ?: "en"
