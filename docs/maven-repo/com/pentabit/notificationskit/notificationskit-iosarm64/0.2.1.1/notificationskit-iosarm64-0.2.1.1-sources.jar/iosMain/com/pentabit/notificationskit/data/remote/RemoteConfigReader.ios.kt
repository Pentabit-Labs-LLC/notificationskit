package com.pentabit.notificationskit.data.remote

import cocoapods.FirebaseRemoteConfig.FIRRemoteConfig
import cocoapods.FirebaseRemoteConfig.FIRRemoteConfigSettings
import com.pentabit.notificationskit.internal.NotificationsKitConstants.LOG_TAG
import kotlinx.cinterop.ExperimentalForeignApi
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Uses FIRRemoteConfig.remoteConfig() — the same per-process singleton the host app's own Remote
 * Config bootstrap already talks to. Requires the host to have already called
 * FirebaseApp.configure() before NotificationsKit.init() runs.
 */
@OptIn(ExperimentalForeignApi::class)
private class IOSRemoteConfigReader : RemoteConfigReader {
    private val remoteConfig: FIRRemoteConfig = FIRRemoteConfig.remoteConfig()

    init {
        val settings = FIRRemoteConfigSettings()
        settings.minimumFetchInterval = 3600.0
        remoteConfig.configSettings = settings
    }

    override suspend fun fetchAndActivate(): Boolean = suspendCoroutine { cont ->
        remoteConfig.fetchWithCompletionHandler { _, error ->
            if (error != null) {
                // Firebase RC falls back to the last-activated/default values on failure --
                // non-fatal, matches the Android actual above and the parent app's own
                // RemoteConfigBootstrap behavior. Still logged: a fetch failure here (e.g. no
                // network on first cold launch, before any value was ever cached) is exactly why
                // a downstream getString() can come back blank even though the console shows a
                // value configured -- this is the log line that explains why.
                println("$LOG_TAG Remote Config fetch failed, falling back to cached/default values: ${error.localizedDescription}")
                cont.resume(true)
            } else {
                remoteConfig.activateWithCompletion { _, _ -> cont.resume(true) }
            }
        }
    }

    override fun getString(key: String): String =
        remoteConfig.configValueForKey(key).stringValue
}

internal actual fun createRemoteConfigReader(): RemoteConfigReader = IOSRemoteConfigReader()
